import logging
import os
import shutil
import json
from optparse import OptionParser
import logging.handlers

#create parser and create -s & -o option arguments
parser = OptionParser()
parser.add_option("-s","--scriptfile",help="script file path",dest="scriptfile")
parser.add_option("-o","--outputfile",help="output/log file path",dest="outputfile")
(options,args)=parser.parse_args()
#(options.scriptfile) to use script path argument




#file name (option.outputfile) which is -o (input)
logging.basicConfig(filename=options.outputfile, filemode='w', level=logging.DEBUG)




""""
filename= options.outputfile

sro= os.path.isfile(filename)
handler=logging.handlers.RotatingFileHandler(filename,mode='w',backupCount=7,delay=True)
if sro:
    handler.doRollover()
    logging.basicConfig(filename = filename, filemode='w',level=logging.DEBUG,delay=True)
"""





#read jason file
jsonfile= open('C:\\Users\\Mohammad Alqam\\PycharmProjects\\pythonProject2\\configuration.json','r')
jdata=jsonfile.read()

#parser
obj=json.loads(jdata)
#obj['output']


#grep function
def find_files(file, directory):
   x="fail"
   result = [x]

# Wlaking top-down from the root
   for root, dir, files in os.walk(directory):
      if file in files:
         result.clear()
         result.append(os.path.join(root, file))
         logging.debug("pass")
   return result


#mv_last function
def mv_last(dir1,dir2):
    #find the most recent file
    files = os.listdir(dir1)
    paths = [os.path.join(dir1, basename) for basename in files]
    dir1 = max(paths, key=os.path.getctime)
    logging.debug(dir1)

    #move the file
    shutil.move(dir1, dir2)
    return 1




#categorize fuction
def categorize(dir):
    #create less and more folders to split files in another directory "E:\displit"
    os.chdir("E:\displit")
    less='less'
    os.mkdir(less)
    more='more'
    os.mkdir(more)

    #check all files if the size less or more than threshold_size and split them
    for file in os.listdir(dir):
         filename = os.fsdecode(file)
         directory_file="E:\\di\\" + filename

         if ((os.stat(directory_file).st_size) < int(obj['threshold_size'])):
              less_dir="E:\\displit\\less\\"+ filename
              shutil.move(directory_file,less_dir)
              logging.debug(filename + " move to less folder ")
         elif ((os.stat(directory_file).st_size) > int(obj['threshold_size'])):
              more_dir='E:\\displit\\more\\'+filename
              shutil.move(directory_file,more_dir)
              logging.debug(filename + " move to more folder ")

    return 1



#(options.scriptfile)the input -s
#read the script file and split each command
with open(options.scriptfile,'r') as f:
    num =0
    for line in f :
        num +=1
        s=line.split()

#get obj['max_command'] from json file and read just #n command equal max
        if num <= int(obj['Max_commands']):
#chek the name of command and do each one what that need and the out put in json file log
           if (s[0] == "Grep" and obj['output'] == "log"):
              logging.debug("--- gerp "+ str(s[1]) +" "+ str(s[2]) + " --- line "+str(num)+" ---")
              t = s[1].replace('<', '')
              d1 = t.replace('>', '')
              q = s[2].replace('<', '')
              d2 = q.replace('>', '')
              grep_dir = find_files(d1, d2)
              logging.debug(grep_dir)
           elif (s[0] == "Categorize" and obj['output'] == "log"):
             logging.debug("--- categorize "+str(s[1])+" --- line "+str(num)+" ---")
             t = s[1].replace('<', '')
             d1 = t.replace('>', '')
             categorize(d1)
           elif (s[0] == "Mv_last" and obj['output'] == "log"):
             logging.debug("--- Mv_last " + str(s[1]) +" "+ str(s[2]) +" --- line "+str(num)+" ---")
             t = s[1].replace('<', '')
             d1 = t.replace('>', '')
             q = s[2].replace('<', '')
             d2 = q.replace('>', '')
             mv_last(d1,d2)


#if output in json file csv
           elif(s[0] == "Grep" and obj['output'] == "csv"):
            logging.debug("grep command ," )
            t = s[1].replace('<', '')
            d1 = t.replace('>', '')
            q = s[2].replace('<', '')
            d2 = q.replace('>', '')
            grep_dir = find_files(d1, d2)
            logging.debug(grep_dir)

           elif (s[0] == "Categorize" and obj['output'] == "csv"):
               t = s[1].replace('<', '')
               d1 = t.replace('>', '')
               if categorize(d1)==1:
                 logging.debug("Categorize command ," + "pass")
               else:
                   logging.debug("Categorize command ," + "fail")

           elif (s[0] == "Mv_last" and obj['output'] == "csv"):
               t = s[1].replace('<', '')
               d1 = t.replace('>', '')
               q = s[2].replace('<', '')
               d2 = q.replace('>', '')
               if mv_last(d1,d2)==1:
                logging.debug("Mv_last command ," + "pass")
               else :
                   logging.debug("Mv_last command ," + "fail")

           else:
               #if you enter the command in wrong way in script file
             logging.error("syntax error in line " + str(num))









